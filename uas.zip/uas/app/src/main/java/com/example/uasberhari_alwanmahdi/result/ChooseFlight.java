package com.example.uasberhari_alwanmahdi.result;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.example.uasberhari_alwanmahdi.Maska;
import com.example.uasberhari_alwanmahdi.R;

import java.util.ArrayList;
import java.util.List;

public class ChooseFlight extends AppCompatActivity {

    //contoh variabel untuk menampilkan TODO 5;
    TextView asal,tujuan,tglBerangkat,tglBail;

    //ini belum terpakai
    //ResultAdapter resultAdapter;

    //Penggunaan Class Maska
    List<Maska> maskaList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_flight);
        asal = findViewById(R.id.asal);
        tujuan = findViewById(R.id.tujuan);
        tglBerangkat = findViewById(R.id.tanggalBerangkat);
        tglBail = findViewById(R.id.tanggalBalik);


        Bundle bundle = getIntent().getExtras();
        asal.setText("Kota asal : "+bundle.getString("asal"));
        tujuan.setText("Kota Tujuan : "+bundle.getString("tujuan"));
        tglBerangkat.setText("Tanggal Berangkat : "+bundle.getString("datepergi"));
        tglBail.setText("Tanggal Balik : "+bundle.getString("datebalik"));



        //load data Maska sebagai list
        maskaList = new ArrayList<>();

        //TODO 5b:Tampilkan informasi kotaasal,tujuan dan tanggal dari pilihan di Tab1/Tab2 disini
        //Hint : berupa inisiasi variabel String, contoh (tanpa karakter bintang) : **String namavariabelkotaasal =**
        //Setting komponen Text di xml nya terlebih dahulu
    }
}
