package com.example.uasberhari_alwanmahdi;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.uasberhari_alwanmahdi.result.ChooseFlight;

public class Tab2 extends Fragment{
    Calendar myCalendar, myCalendar2;
    TextView date, asal, balik, tglasal, tglbalik, chooseHarga;

    EditText datePergi, dateBalik;

    Button btnSearch;
    DatePickerDialog.OnDateSetListener date1, date2;
    Switch switchBalik;
    String kotaasal, kotatuju;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View myView = inflater.inflate(R.layout.fragment_tab2,container,false);
        datePergi = myView.findViewById(R.id.editText1);
        dateBalik = myView.findViewById(R.id.editText2);

        final String[] listtuju = {"--Pilih Negara", "Singapur", "Malaysia", "New Zealand", "Amerika Serikat", "Belanda", "Jepang", "Norwegia"};
        final String[] listasal = {"--Pilih Negara", "Singapur", "Malaysia", "New Zealand", "Amerika Serikat", "Belanda", "Jepang", "Norwegia"};
        asal = myView.findViewById(R.id.textView1);
        balik = myView.findViewById(R.id.textView3);
        tglasal = myView.findViewById(R.id.textView2);
        tglbalik = myView.findViewById(R.id.textView4);
        chooseHarga = myView.findViewById(R.id.textView5);
        final Spinner pilihFrom = myView.findViewById(R.id.spinner1);
        final Spinner pilihTo = myView.findViewById(R.id.spinner2);
        btnSearch = myView.findViewById(R.id.button1);
        switchBalik= myView.findViewById(R.id.switch1);
        switchBalik.setChecked(false);

        switchBalik.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){

                    dateBalik.setEnabled(true);
                } else {
                    dateBalik.getText().clear();
                    dateBalik.setEnabled(false);
                    tglbalik.setText("");
                }
            }
        });

        myCalendar = Calendar.getInstance();
        myCalendar2 = Calendar.getInstance();

        date1 = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                updateLabel();
            }
        };

        //TODO 3a : tambahkan picker untuk tanggal tujuan
        //seperti date1 di atas
        //Hint **date2 =**
        date2 = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                updateLabel2();
            }
        };

        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(),android.R.layout.simple_spinner_item,listasal);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        pilihFrom.setAdapter(adapter);

        //TODO 3b : tambahkan adapter untuk tanggal tujuan
        //seperti final ArrayAdapter<String> adapter di atas
        //ganti adapter => adapter1, listasal => listtuju , pilihFrom => pilihTo

        final ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this.getActivity(),android.R.layout.simple_spinner_item,listtuju);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        pilihTo.setAdapter(adapter);

        pilihFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0:
                        kotaasal = "";
                        break;
                    case 1:
                        kotaasal = "DJJ";
                        break;
                    case 2:
                        kotaasal = "BPN";
                        break;
                    case 3:
                        kotaasal = "SRG";
                        break;
                    case 4:
                        kotaasal = "UPG";
                        break;
                    case 5:
                        kotaasal = "BDG";
                        break;
                    case 6:
                        kotaasal = "SUB";
                        break;
                    case 7:
                        kotaasal = "CGK";
                        break;


                }
                asal.setText("Dari   : "+adapter.getItem(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //TODO 3c : tambahkan selectedListener baru untuk Spinner pilihTo
        //seperti pilihFrom.setOnItemSelectedListener di atas
        //ganti pilihFrom => pilihTo, asal.setText => balik.setText , adapter.getItem => adapter1.getItem

        pilihTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0:
                        kotaasal = "";
                        break;
                    case 1:
                        kotaasal = "DJJ";
                        break;
                    case 2:
                        kotaasal = "BPN";
                        break;
                    case 3:
                        kotaasal = "SRG";
                        break;
                    case 4:
                        kotaasal = "UPG";
                        break;
                    case 5:
                        kotaasal = "BDG";
                        break;
                    case 6:
                        kotaasal = "SUB";
                        break;
                    case 7:
                        kotaasal = "CGK";
                        break;


                }
                balik.setText("Ke   : "+adapter1.getItem(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        datePergi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(getAktivitas(),date1,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        //TODO 3d : tambahkan OnClickListener baru untuk tanggal balik
        //seperti datePergi.setOnClickListener di atas
        //ganti datePergi => dateBalik, date1,myCalendar => date2,myCalendar2 , myCalendar => myCalendar2
        dateBalik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(getAktivitas(),date2,myCalendar2.get(Calendar.YEAR),myCalendar2.get(Calendar.MONTH),myCalendar2.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        //TODO 5a:Set Activity lain yang jika tombol Search diklik muncul Halaman baru ..(berlanjut di 5b)
        //contoh Class ChooseFlight dengan xml activity_choose_flight.xml
        //bisa pakai ChooseFligt saja atau buat baru
        //untuk Search dari Tab1 atau Tab2
        //Hint **btnSearch.setOnClickListener**

        ////btnSearch.setOnClickListener
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "jalan", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(getContext(), ChooseFlight.class)
                        .putExtra("asal",asal.getText().toString())
                        .putExtra("tujuan",balik.getText().toString())
                        .putExtra("datepergi",datePergi.getText().toString())
                        .putExtra("datebalik",dateBalik.getText().toString());
                getContext().startActivity(intent);
            }
        });

        //TODO 3:Ubah layout dari Tab1 sekreatif kalian
        //layout Tab1 dengan Tab2 bisa berbeda
        //TODO 4:Tambahkan Clickable Image logo beberapa maskapai dan terapkan Inten Implicit ke halaman alamat web maskapai.
        //(di space kosong;atur proporsi dan kerapihan);Tidak harus bisa back

        return myView;

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 5){
            if(resultCode == Activity.RESULT_OK){
                chooseHarga.setText("-> "+data.getStringExtra("harga"));

            }
            if (resultCode == Activity.RESULT_CANCELED){

            }
        }
    }

    public Context getAktivitas(){
        return Tab2.this.getActivity();
    }

    private void updateLabel2() {
        String myformat = "yyyy-MM-dd";
        SimpleDateFormat sdg = new SimpleDateFormat(myformat, Locale.US);
        dateBalik.setText(sdg.format(myCalendar2.getTime()));
        dateBalik.setTextColor(getResources().getColor(R.color.colorPrimary));
    }

    private void updateLabel() {
        String myformat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(myformat, Locale.US);
        datePergi.setText(sdf.format(myCalendar.getTime()));
        datePergi.setTextColor(getResources().getColor(R.color.colorPrimary));
    }



}
